# WUDI firmware

`stm32/wudi_encoder16` is the WUDI-owned acquisition firmware for the physical
16-sensor exoskeleton. It streams all sixteen ADC samples; the unmodified
DexUMI board provides fourteen encoder-signal routes and two hard-wired
3V3/GND diagnostics. The firmware is derived from the MIT-licensed DexUMI STM32
project at reference revision `acddb8f8a89a8f0186868bbec44306eb7808114a`.
DexUMI remains an independent reference project; the firmware needed to build
and reproduce WUDI is vendored here.

Generated build output lives below each firmware project's `build/` directory
and is ignored by Git. Source, linker scripts, CubeMX configuration, and
license notices are tracked.
