# WUDI Encoder16 firmware

## Hardware target

- STM32F042K6T6, 32 KiB Flash / 6 KiB SRAM
- two ADS1256 ADCs on the DexUMI acquisition PCB
- 16 installed ALPS RDC506018A encoders, of which 14 can reach encoder
  signal inputs on the unmodified DexUMI acquisition PCB
- USART1 PB6/TX and PB7/RX at 921600 baud, 8N1
- SWD on PA13/SWDIO and PA14/SWCLK

## ADC and packet order

The firmware samples every ADS1256 mux input in this fixed physical order:

1. ADS1256 device 0, AIN0 through AIN7;
2. ADS1256 device 1, AIN0 through AIN7.

The DexUMI XHand firmware establishes the board-level meaning of those inputs:

| Packet channel | ADS1256 input | DexUMI board role |
| ---: | --- | --- |
| 0-7 | device 0 AIN0-7 | encoder signals `00`-`07` |
| 8-11 | device 1 AIN0-3 | encoder signals `08`-`11` |
| 12 | device 1 AIN4 | `NC1`-labeled but electrically routed encoder signal |
| 13 | device 1 AIN5 | `NC2`-labeled but electrically routed encoder signal |
| 14 | device 1 AIN6 | `3V3` supply reference |
| 15 | device 1 AIN7 | `GND` reference |

This follows from both the reference firmware and the checked PCB fabrication
netlist. The XHand firmware skips device 1 AIN4-5 because its target has twelve
joints, but the PCB routes those inputs to the `NC1`/`NC2` connector center
pins with 3V3 and ACOM on the outer pins. Device 1 AIN6 is tied to 3V3 and AIN7
to ACOM. The host uses the penultimate value as its supply reference and removes
both final values from the joint-angle array.

Every UART packet is 72 bytes, little-endian:

| Offset | Size | Meaning |
| --- | ---: | --- |
| 0 | 4 | protocol header `AA 55 10 01` |
| 4 | 64 | 16 signed int32 ADS1256 counts in the order above (14 encoder-capable signals plus two board diagnostics) |
| 68 | 2 | 16-bit millisecond device timestamp |
| 70 | 2 | low 16 bits of the sum of all signed count words |

Channel 14 contains the 3V3 supply-reference measurement used for the GUI's
nominal ratiometric display. Raw counts remain authoritative. Production
count-to-angle conversion must still come from measured per-channel
calibration.

Reading all 16 mux inputs in firmware does not create 16 encoder-capable board
ports. `NC1` and `NC2` are usable despite their names, but `3V3` and `GND` are
rails, not encoder wiper inputs. Using all 16 installed encoders requires a
hardware change that provides two additional analogue signal routes (and a
reviewed reference strategy).

## Build

Install the Arm GNU Embedded toolchain, then run:

```bash
make -C firmware/stm32/wudi_encoder16 clean
make -C firmware/stm32/wudi_encoder16 -j4
```

The Makefile uses `arm-none-eabi-*` from `PATH`, or automatically discovers a
complete Arm GNU toolchain installed under
`~/.local/opt/arm-gnu-toolchain-*/bin`. `GCC_PATH=/custom/toolchain/bin` remains
available as an explicit override.

Outputs are `build/WUDI_Encoder16.elf`, `.hex`, and `.bin`.

## Probe and flash

Always probe first and confirm STM32F04x with 32 KiB Flash:

```bash
st-info --probe
```

Back up the existing Flash before the first WUDI write:

```bash
mkdir -p results/hardware/firmware_backups
st-flash read \
  results/hardware/firmware_backups/stm32f042_flash_before_wudi_encoder16.bin \
  0x08000000 0x8000
```

Write the binary only after a successful build and protocol tests:

```bash
st-flash --reset write \
  firmware/stm32/wudi_encoder16/build/WUDI_Encoder16.bin \
  0x08000000
```

Then validate the 72-byte stream with `tools/check_encoder_stream.py` before
changing the hardware config to `production_ready`.

The first target was flashed and read back successfully on 2026-08-12. The
binary and readback SHA-256 are both
`0ddb9dcba86dc33f97ae636f923d219fb492d62f53ba763dddd8e0c77025e3d9`.

## Provenance

The project was derived from the DexUMI embedded system at revision
`acddb8f8a89a8f0186868bbec44306eb7808114a`. Its MIT license is retained as
`LICENSE.dexumi`; ST HAL/CMSIS files retain their upstream license headers and
license files.
